<?
include("../db_class_info.php");      //include oracle class file
import_request_variables("gP","var_");  // get all  post variables and append with var
?>
<html>
<head>
<title>User Info</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="pragma" content="no-cache">
<link href="../../StyleSheets/mypage.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="1247" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr> 
    <td height="60" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr> 
          <td width="1248" height="56"><img src=".././images/banner2.jpg" width="1248" height="60"></td>
          <td width="4"></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="13" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1247" height="13">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="196" height="776" valign="top"><table width="196" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="196" height="776" bgcolor="#006699">
		<div id="navlist"> 
              <ul>
                <li class="tbletitle"> 
                  <div align="center">Admin Functions</div>
                </li>
                <li><a href="./UserAdd.php">Add User</a></li>
                <li><a href="./Delete_User.php">Delete User</a></li>
                <li><a href="./UserInfo.php">View User</a></li>
                <li><a href="./Modify_User.php">Modify User</a></li>
                <li class="tbletitle"> 
                  <div align="center">Patient Functions</div>
                </li>
                <li><a href="../Patient/View_Patient.php">View Patient</a></li>
                <li><a href="../Patient/Add_Patient.php">Add Patient</a></li>
                <li><a href="../Patient/Delete_Patient.php">Delete Patient</a></li>
                <li><a href="../Patient/Modify_Patient.php">Modify Patient</a></li>
                <li><a href="../Patient/PatientInfo.php">Patient Outcome</a></li>
                <li><a href="../Patient/PatientInfo.php"> Complication
                  Info</a></li>
                <li><a href="../Patient/PatientInfo.php">Patient Diagnosis</a></li>
                <li><a href="../Patient/PatientInfo.php"> Patient Image</a></li>
                <li class="tbletitle"> 
                  <div align="center">Hospital Functions</div>
                </li>
                <li><a href="./Add_Hospital.php"> New Hospital</a></li>
                <li><a href="./Modify_Hospital.php">Modify Hospital</a></li>
                <li><a href="./Reports.php">Generate Reports</a></li>
                <li><a href="./Edit_Lists.php">Maintain Lists</a></li>
                <li><a href=".././logout.php">Logout</a></li>
              </ul>
            </div>
		�</td>
      </tr>
    </table></td>
    <td width="13" valign="top"><table width="13" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="13" height="776">&nbsp;</td>
      </tr>
    </table></td>
    <td width="1038" valign="top"><table width="1038" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1038" height="170" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="1042" height="170">
			<form method="post" enctype="multipart/form-data" name="query" target="_self" id="query">
              <table border="0" align="left" class="border">
    <tr class="tbletitle"> 
      <td colspan="3" align="center">User Search </td>
    </tr>
    <tr>
      <td  align="right" class="style4"><div align="right">Search For
              
      </div></td>
      <td ><input name="query" type="text" size="35" maxlength="25"></td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td  align="right" class="style4"><div align="right">Search By &nbsp; </div></td>
      <td >        <span class="style4">
        <select name="search_by" id="search_by">
          <option value="Last_Name">Lastname</option>
          <option value="First_Name">Firstname</option>
          <option value="Userid" selected>Userid</option>
        </select>
        </span></td>
          <td>&nbsp;</td>
    </tr>
    <tr>
      <td align="right" class="style4"><div align="right"><span class="style4">&nbsp;Type of User </span>
      </div></td>
      <td align="left"><select name="user_type" id="select4">
        <option value="all" selected>All</option>
        <option value="admin">Admin</option>
        <option value="surgeon">Surgeon</option>
        <option value="user">User</option>
      </select></td>
      <td align="left">&nbsp;</td>
    </tr>
    <tr> 
      <td align="right" class="style4"><div align="right" class="style4">Sort by </div></td>
      <td align="left"><div align="left"><span class="style4">
        <select name="sort_by" size="1" id="select2">
          <option value="Userid" selected>Userid</option>
          <option value="Last_Name">Last name</option>
          <option value="First_Name">First name</option>
        </select>
      </span>
      </div></td>
      <td align="left"><input type="submit" name="Query" value="Search"></td>
    </tr>
  </table>
			</form>  			</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="606" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="1038" height="606" bgcolor="#FFFFFF" valign="top" align="left">
			<br>
			<?	if(isset($var_Query))
	{
	 $results = array();	
	 $db = new Oracle;  
   	 $db->logOn();
	 $select= "*";
	 $from = $db->User_table;
     switch($var_user_type)
			{
			 case "all" :
			 $where = $var_search_by." LIKE '%$var_query%'";
			 break;
			 case "admin" :
			 $where = $var_search_by." LIKE '%$var_query%' and Position = '1'";
			  break;
			 case "surgeon":
			 $where = $var_search_by." LIKE '%$var_query%' and Position = '2'";
			 break;
			 case "user":
			 $where = $var_search_by." LIKE '%$var_query%' and Position =  '3'";
			 break;
			}
	 $db->queryDB($select,$from,$where);
	 $i = 0;
	 while ($db->fetch()) //check password
	      {  
		    $i++;
             if ($i==1)  
 				{
					echo('<form action="" method="post"  name="form2" id="form2" target="_self">
							<table width="97%" border="0" align="left" class="border">
							  <tr class="style4">
								<th width="13%"  scope="col"><a href="UserInfo.php" target="_self">Record</a></th>
								<th width="13%"  scope="col">Userid</th>
								<th width="13%"  scope="col">Last Name </th>
								<th width="13%"  scope="col">Firstname</th>
								<th width="13%"  scope="col">Hospid</th>
								<th width="13%"  scope="col">Position</th>
								<th width="7%"   scope="col"> <input name="Info" type="submit" id="Info" value="Info"></th>
								<th width="7%"   scope="col"><input name="Modify" type="submit" id="Modify" value="Modify"></th>
								<th width="7%"   scope="col"><input name="Delete" type="submit" id="Delete" value="Delete"></th>
							  </tr>');
				}
	      	if ($i%2 == 0)
	      	  $bg = "#0568A3";
	      	else $bg = "#FFFFFF";  
	        $found = "true";
            $results=$db->result_array; 
			$userid	   = $results['Userid'];
	        $lastname  = $results['Last_Name'];   
			$firstname = $results['First_Name'];   
	        $address1  = $results['Address1'];   
	        $city      = $results['City'];
			$state     = $results['State'];   
			$zip       = $results['Zip'];   
	        $pwd1      = $results['Passwd11'];   
	        $pwd2      = $results['Passwd2'];   
			$regdate   = $results['REG_DATE'];
			$hospid	   = $results['Hospid'];
			$position  = $results['Position'];
		    echo('<tr class="style4" bgcolor='.$bg.'>
                <td align= "right">'.$i.'</td> <td align= "right">'.$userid.'</td>
                <td align= "right">'.$lastname.'</td> <td align= "right">'.$firstname.'</td>
                <td align= "right">'.$hospid.' </td>  <td align= "right">'.$position.' </td>
                <td align="center"> <input type="checkbox" name="checkbox" value="checkbox"> </td>
                <td align="center"> <input type="checkbox" name="checkbox2" value="checkbox"> </td>
                <td align="center"><input type="checkbox" name="checkbox3" value="checkbox"> </td>
              </tr>');
					  
          }  
	     echo('</table></form> <br>'); 
		 if ($i==0 || $found!="true") 
		   {
		    echo('<p align="center" class = "style4">Record Not Found<p>');
		   }
        $db->logOff();  
     }//end like query
 
	 
?></td> </tr> </table> </td>
  </tr> </table> </td>
  </tr> </table>
</body>
</html>