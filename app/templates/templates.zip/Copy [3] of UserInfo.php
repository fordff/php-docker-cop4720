<?
include("../db_class_info.php");      //include oracle class file
import_request_variables("gP","var_");  // get all  post variables and append with var

  if($var_Modify)
    {
     $db = new Oracle;  
   	 $db->logOn();
     $table = $db->User_table;
	 $condition = "Userid = '".$var_Old_id."'";
	 
	 $set = "Last_Name = '".$var_new_lastname."'";
	 $db->updateDB($table,$set,$condition);
	 $set =  "First_Name = '".$var_new_firstname."'";
	 $db->updateDB($table,$set,$condition);
	 $set =  "Address1 = '".$var_new_address1."'";
	 $db->updateDB($table,$set,$condition);
	 $set =  "City = '".$var_new_city."'";
	 $db->updateDB($table,$set,$condition);
     $set =  "State = '".$var_State."'";
	 $db->updateDB($table,$set,$condition);
	  $set =  "Zip = '".$var_new_zip."'";
	 $db->updateDB($table,$set,$condition);
	 $set =  "Passwd1 = '".$var_new_pwd1."'";
	 $db->updateDB($table,$set,$condition);
	 $set =  "Passwd2 = '".$var_new_pwd2."'";
	 $db->updateDB($table,$set,$condition);
     $set =  "Position= '".$var_position."'";
	 $db->updateDB($table,$set,$condition);
     $set =  "Hospid= '".$var_hospital."'";
	 $db->updateDB($table,$set,$condition);
	 $db->logOff();
   }//end 
if($var_delete)
   {
     $db = new Oracle;  
   	 $db->logOn();
     $from = $db->User_table;
     $where = "Userid =  '$var_Old_id'";
     $db->deleteDB($from,$where);
     $db->logOff();  
     
    }


?>
<html>
<head>
<title>User Info</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="pragma" content="no-cache">
<link href="../../StyleSheets/mypage.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="1247" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr> 
    <td height="60" colspan="5" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr> 
          <td width="1248" height="56"><img src=".././images/banner2.jpg" width="603" height="60"></td>
          <td width="4"></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="13" colspan="5" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1247" height="13" bgcolor="#000000">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="196" rowspan="3" valign="top"><table width="196" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="196" height="776" bgcolor="#006699">
		<div id="navlist"> 
              <ul>
                <li class="tbletitle"> 
                  <div align="center">Admin Functions</div>
                </li>
                <li><a href="./UserAdd.php">Add User</a></li>
                <li><a href="./Delete_User.php">Delete User</a></li>
                <li><a href="./UserInfo.php">View User</a></li>
                <li><a href="./Modify_User.php">Modify User</a></li>
                <li class="tbletitle"> 
                  <div align="center">Patient Functions</div>
                </li>
                <li><a href="../Patient/View_Patient.php">View Patient</a></li>
                <li><a href="../Patient/Add_Patient.php">Add Patient</a></li>
                <li><a href="../Patient/Delete_Patient.php">Delete Patient</a></li>
                <li><a href="../Patient/Modify_Patient.php">Modify Patient</a></li>
                <li><a href="../Patient/PatientInfo.php">Patient Outcome</a></li>
                <li><a href="../Patient/PatientInfo.php"> Complication
                  Info</a></li>
                <li><a href="../Patient/PatientInfo.php">Patient Diagnosis</a></li>
                <li><a href="../Patient/PatientInfo.php"> Patient Image</a></li>
                <li class="tbletitle"> 
                  <div align="center">Hospital Functions</div>
                </li>
                <li><a href="./Add_Hospital.php"> New Hospital</a></li>
                <li><a href="./Modify_Hospital.php">Modify Hospital</a></li>
                <li><a href="./Reports.php">Generate Reports</a></li>
                <li><a href="./Edit_Lists.php">Maintain Lists</a></li>
                <li><a href=".././logout.php">Logout</a></li>
              </ul>
            </div>
		�</td>
      </tr>
    </table></td>
    <td width="13" rowspan="3" valign="top"><table width="13" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="13" height="776" bgcolor="#000000">&nbsp;</td>
      </tr>
    </table></td>
    <td width="31" height="55">&nbsp;</td>
    <td width="950">&nbsp;</td>
    <td width="57">&nbsp;</td>
  </tr>
  <tr>
    <td height="703"></td>
    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="950" height="703" valign="top">
<form action="" method="post" enctype="multipart/form-data" name="new_entry" target="_self" id="new_entry">
   <br>
  <table width="520" border="0" align="center" class="border">
    <tr> 
      <td colspan="2" class="tbletitle">User Info</td>
    </tr>
    <tr> 
      <td width="112" class="style4"><div align="right">Last Name</div></td>
      <td class="style4"> 
        <?php
	   echo("<input name='new_lastname' type='text' id='new_lastname' size='25' maxlength='25' value = '$lastname'>");
	   ?>
      </td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">First Name</div></td>
      <td class="style4"> <?php echo(" <input name='new_firstname' type='text' id='new_firstname' size='25' maxlength='25' value = '$firstname'>"); ?></td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Address</div></td>
      <td class="style4"> <?php echo(" <input name='new_address1' type='text' id='new_address1' size='25' maxlength='25' value = '$address1'>"); ?></td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">City</div></td>
      <td class="style4"> <?php echo(" <input name='new_city' type='text' id='new_city' size='25' maxlength='25' value = '$city'>"); ?></td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">State</div></td>
      <td class="style4"> <SELECT name="State">
          <option value="AL" selected>Alabama</option>
          <option value="AK">Alaska</option>
          <option value="AZ">Arizona</option>
          <option value="AR">Arkansas</option>
          <option value="CA">California</option>
          <option value="CO">Colorado</option>
          <option value="CT">Connecticut</option>
          <option value="DE">Delaware</option>
          <option value="DC">District of Columbia</option>
          <option value="FL">Florida</option>
          <option value="GA">Georgia</option>
          <option value="HI">Hawaii</option>
          <option value="ID">Idaho</option>
          <option value="IL">Illinois</option>
          <option value="IN">Indiana</option>
          <option value="IA">Iowa</option>
          <option value="KS">Kansas</option>
          <option value="KY">Kentucky</option>
          <option value="LA">Louisiana</option>
          <option value="ME">Maine</option>
          <option value="MD">Maryland</option>
          <option value="MA">Massachusetts</option>
          <option value="MI">Michigan</option>
          <option value="MN">Minnesota</option>
          <option value="MS">Mississippi</option>
          <option value="MO">Missouri</option>
          <option value="MT">Montana</option>
          <option value="NE">Nebraska</option>
          <option value="NV">Nevada</option>
          <option value="NH">New Hampshire</option>
          <option value="NJ">New Jersey</option>
          <option value="NM">New Mexico</option>
          <option value="NY">New York</option>
          <option value="NC">North Carolina</option>
          <option value="ND">North Dakota</option>
          <option value="OH">Ohio</option>
          <option value="OK">Oklahoma</option>
          <option value="OR">Oregon</option>
          <option value="PA">Pennsylvania</option>
          <option value="RI">Rhode Island</option>
          <option value="SC">South Carolina</option>
          <option value="SD">South Dakota</option>
          <option value="TN">Tennessee</option>
          <option value="TX">Texas</option>
          <option value="UT">Utah</option>
          <option value="VT">Vermont</option>
          <option value="VA">Virginia</option>
          <option value="WA">Washington</option>
          <option value="WV">West Virginia</option>
          <option value="WI">Wisconsin</option>
          <option value="WY">Wyoming</option>
          <option value="PR">Puerto Rico</option>
          <option value="VI">Virgin Island</option>
          <option value="MP">Northern Mariana Islands</option>
          <option value="GU">Guam</option>
          <option value="AS">American Samoa</option>
          <option value="PW">Palau</option>
      </SELECT> <? echo($state); ?> </td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Zip</div></td>
      <td class="style4"> <?php echo("  <input name='new_zip' type='text' id='new_zip' size='8' maxlength='8' value = '$zip'>"); ?></td>
    </tr>
    <tr> 
      <td height="26" class="style4"><div align="right">Password 1</div></td>
      <td class="style4"> <?php echo("  <input name='new_pwd1' type='text' id='new_pwd1' size='25' maxlength='25' value = '$pwd1'> "); ?></td>
    </tr>
    <tr> 
      <td height="26" class="style4"><div align="right">Password 2</div></td>
      <td class="style4"> <?php echo("  <input name='new_pwd2' type='text' id='new_pwd2' size='25' maxlength='25' value = '$pwd2'>") ;?></td>
    </tr>
    <tr> 
      <td height="26" class="style4"><div align="right">Job Title</div></td>
      <td class="style4"><select name="position" id="position">
          <option value="1" selected>User</option>
          <option value="2">Surgeon</option>
          <option value="3">Adminstrator</option>
        </select>
      <? echo($position); ?> </td>
    </tr>
    <tr> 
      <td height="26" class="style4"><div align="right">Hospital</div></td>
      <td class="style4"><select name="hospital" id="select3">
          <option value="UF" selected>Shands at UF</option>
          <option value="Shands">Shands at AGH</option>
          <option value="VA">Verterans Administration-Gainesville</option>
      </select> <? echo($hospid); ?> </td>
    </tr>
    <tr> 
      <td height="26" > <div align="right"> 
        </div></td>
      <td><input name="Modify" type="submit" id="Modify" value="Modify">
        <input type="submit" name="Submit" value="Delete"></td>
    </tr>
  </table>
</form>&nbsp;</td>
      </tr>
    </table></td>
    <td></td>
  </tr>
  <tr>
    <td height="18"></td>
    <td></td>
    <td></td>
  </tr> 
  </table>
</body>
</html>