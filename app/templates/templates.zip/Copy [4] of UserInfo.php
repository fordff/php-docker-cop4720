<?
include("../db_class_info.php");      //include oracle class file
import_request_variables("gP","var_");  // get all  post variables and append with var
?>
<html>
<head>
<title>User Info</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="pragma" content="no-cache">
<link href="../../StyleSheets/mypage.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body>

<div id="Layer1" style="position:absolute; left:384px; top:266px; width:1px; height:0px; z-index:1"></div>
<table width="1247" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr> 
    <td height="60" colspan="5" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr> 
          <td width="1248" height="56"><img src=".././images/banner2.jpg" width="1248" height="60"></td>
          <td width="4"></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="19" colspan="5" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1247" height="13" bgcolor="#000000">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="196" rowspan="4" valign="top"><table width="196" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="196" height="776" bgcolor="#006699">
		<div id="navlist"> 
              <ul>
                <li class="tbletitle"> 
                  <div align="center">Admin Functions</div>
                </li>
                <li><a href="./UserAdd.php">Add User</a></li>
                <li><a href="./Delete_User.php">Delete User</a></li>
                <li><a href="./UserInfo.php">View User</a></li>
                <li><a href="./Modify_User.php">Modify User</a></li>
                <li class="tbletitle"> 
                  <div align="center">Patient Functions</div>
                </li>
                <li><a href="../Patient/View_Patient.php">View Patient</a></li>
                <li><a href="../Patient/Add_Patient.php">Add Patient</a></li>
                <li><a href="../Patient/Delete_Patient.php">Delete Patient</a></li>
                <li><a href="../Patient/Modify_Patient.php">Modify Patient</a></li>
                <li><a href="../Patient/PatientInfo.php">Patient Outcome</a></li>
                <li><a href="../Patient/PatientInfo.php"> Complication
                  Info</a></li>
                <li><a href="../Patient/PatientInfo.php">Patient Diagnosis</a></li>
                <li><a href="../Patient/PatientInfo.php"> Patient Image</a></li>
                <li class="tbletitle"> 
                  <div align="center">Hospital Functions</div>
                </li>
                <li><a href="./Add_Hospital.php"> New Hospital</a></li>
                <li><a href="./Modify_Hospital.php">Modify Hospital</a></li>
                <li><a href="./Reports.php">Generate Reports</a></li>
                <li><a href="./Edit_Lists.php">Maintain Lists</a></li>
                <li><a href=".././logout.php">Logout</a></li>
              </ul>
            </div>
		�</td>
      </tr>
    </table></td>
    <td width="13" rowspan="4" valign="top"><table width="13" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="13" height="776" bgcolor="#000000">&nbsp;</td>
      </tr>
    </table></td>
    <td width="42" height="21">&nbsp;</td>
    <td width="950">&nbsp;</td>
    <td width="48">&nbsp;</td>
  </tr>
  <tr>
    <td height="351">&nbsp;</td>
    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr>
          <td width="950" height="5"></td>
        </tr>
        <tr>
          <td height="346" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
        </tr>
    </table></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="51">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="353">&nbsp;</td>
    <td valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr>
          <td width="950" height="353" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
        </tr>
    </table></td>
    <td>&nbsp;</td>
  </tr>
  </table>
</body>
</html>