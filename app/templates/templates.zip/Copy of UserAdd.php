<?
include("../db_class_info.php");      //include oracle class file
import_request_variables("gP","var_");  // get all  post variables and append with var
if (isset($var_add))
	{
     $results = array();	
	 $db = new Oracle;  
   	 $db->logOn();
	 $select= "*";
	 $from = $db->User_table;
	 $where = "Userid ='$var_userid'";
	 $db->queryDB($select,$from,$where);
	 if ($db->fetch()) //check password
	      {  
	        $found = "true";
            $error	   = "User Already in Database";
	      }  
	       else 
			 {				
				 $blank = "";
		 	     $regdate = date("d\-M\-y"); 
				 $table = $db->User_table;
				 $theValues = array();
				 $theValues[0]     = stripslashes($var_userid);
				 $theValues[1]     = stripslashes($var_lastname);
				 $theValues[2]     = stripslashes($var_firstname);
				 $theValues[3]     = stripslashes($var_address);
				 $theValues[4]     = stripslashes($var_city);
				 $theValues[5]     = $var_State;
				 $theValues[6]     = stripslashes($var_zip);
				 $theValues[7]     = stripslashes($var_pwd1);
				 $theValues[8]     = stripslashes($var_pwd2);
				 $theValues[9]     = $regdate;
				 $theValues[10]    = $var_hospital;
				 $theValues[11]    = $_SESSION['USER_ID'];
				 $theValues[12]    = $regdate;//to_date($date, 'mm-dd-yyyy hh:mi:ssam');
				 $db->insertDB($table,$theValues); 
				 $db->logOff();
			 }
	  $_SESSION['ERROR'] = $error;
	}
?>
<html>
<head>
<title>Add Patient</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../../StyleSheets/mypage.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="1247" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr> 
    <td height="60" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr> 
          <td width="1248" height="56"><img src=".././images/banner2.jpg" width="1248" height="60"></td>
          <td width="4"></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="13" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1247" height="13">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="196" height="776" valign="top"><table width="196" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="196" height="776" bgcolor="#006699">
        <div id="navlist"> 
              <ul>
                <li class="tbletitle"> 
                  <div align="center">Admin Functions</div>
                </li>
                <li><a href="./UserAdd.php">Add User</a></li>
                <li><a href="./Delete_User.php">Delete User</a></li>
                <li><a href="./UserInfo.php">View User</a></li>
                <li><a href="./Modify_User.php">Modify User</a></li>
                <li class="tbletitle"> 
                  <div align="center">Patient Functions</div>
                </li>
                <li><a href="../Patient/View_Patient.php">View Patient</a></li>
                <li><a href="../Patient/Add_Patient.php">Add Patient</a></li>
                <li><a href="../Patient/Delete_Patient.php">Delete Patient</a></li>
                <li><a href="../Patient/Modify_Patient.php">Modify Patient</a></li>
                <li><a href="../Patient/PatientInfo.php">Patient Outcome</a></li>
                <li><a href="../Patient/PatientInfo.php"> Complication
                  Info</a></li>
                <li><a href="../Patient/PatientInfo.php">Patient Diagnosis</a></li>
                <li><a href="../Patient/PatientInfo.php"> Patient Image</a></li>
                <li class="tbletitle"> 
                  <div align="center">Hospital Functions</div>
                </li>
                <li><a href="./Add_Hospital.php"> New Hospital</a></li>
                <li><a href="./Modify_Hospital.php">Modify Hospital</a></li>
                <li><a href="../Admin/Reports.php">Generate Reports</a></li>
                <li><a href="../Edit_Lists.php">Maintain Lists</a></li>
                <li><a href=".././logout.php">Logout</a></li>
              </ul>
            </div>
            &nbsp;</td>
      </tr>
    </table></td>
    <td width="13" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="13" height="776">&nbsp;</td>
      </tr>
    </table></td>
    <td width="1038" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1038" height="170" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="1042" height="170"><!--DWLayoutEmptyCell-->&nbsp; </td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="606" valign="top"><table width="1038" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="1038" height="606" bgcolor="#FFFFFF" valign="top"><br>
<form action="" method="post" enctype="multipart/form-data" name="new_entry" target="_self" id="new_entry">
  <table width="819" border="0" align="left"  bgcolor="#CCCCCC" class="border">
    <tr> 
      <td colspan="7" class="tbletitle">User Info</td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">User ID</div></td>
      <td colspan="6"><input name="userid" type="text" id="userid" size="25" maxlength="15"></td>
    </tr>
    <tr> 
      <td width="119" class="style4"><div align="right">Last name</div></td>
      <td width="131"><input name="lastname" type="text" id="lastname" size="25" maxlength="30">        </td>
      <td width="96" ><div align="right" class="style4">
        <div align="right">First name </div>
      </div></td>
      <td width="162" ><input name="firstname" type="text" id="firstname5" size="25" maxlength="30"></td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Address</div></td>
      <td colspan="6"><input name="address" type="text" id="address2" size="25" maxlength="50"></td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">City</div></td>
      <td><input name="city" type="text" id="city2" size="25" maxlength="25"></td>
      <td><div align="right" class="style4">
        <div align="right">State<font face="Arial, Helvetica, Verdana, sans-serif" size="2">
        </font></div>
      </div></td>
      <td><font face="Arial, Helvetica, Verdana, sans-serif" size="2">
        <select name="State">
          <option value="AL" selected>Alabama</option>
          <option value="AK">Alaska</option>
          <option value="AZ">Arizona</option>
          <option value="AR">Arkansas</option>
          <option value="CA">California</option>
          <option value="CO">Colorado</option>
          <option value="CT">Connecticut</option>
          <option value="DE">Delaware</option>
          <option value="DC">District of Columbia</option>
          <option value="FL">Florida</option>
          <option value="GA">Georgia</option>
          <option value="HI">Hawaii</option>
          <option value="ID">Idaho</option>
          <option value="IL">Illinois</option>
          <option value="IN">Indiana</option>
          <option value="IA">Iowa</option>
          <option value="KS">Kansas</option>
          <option value="KY">Kentucky</option>
          <option value="LA">Louisiana</option>
          <option value="ME">Maine</option>
          <option value="MD">Maryland</option>
          <option value="MA">Massachusetts</option>
          <option value="MI">Michigan</option>
          <option value="MN">Minnesota</option>
          <option value="MS">Mississippi</option>
          <option value="MO">Missouri</option>
          <option value="MT">Montana</option>
          <option value="NE">Nebraska</option>
          <option value="NV">Nevada</option>
          <option value="NH">New Hampshire</option>
          <option value="NJ">New Jersey</option>
          <option value="NM">New Mexico</option>
          <option value="NY">New York</option>
          <option value="NC">North Carolina</option>
          <option value="ND">North Dakota</option>
          <option value="OH">Ohio</option>
          <option value="OK">Oklahoma</option>
          <option value="OR">Oregon</option>
          <option value="PA">Pennsylvania</option>
          <option value="RI">Rhode Island</option>
          <option value="SC">South Carolina</option>
          <option value="SD">South Dakota</option>
          <option value="TN">Tennessee</option>
          <option value="TX">Texas</option>
          <option value="UT">Utah</option>
          <option value="VT">Vermont</option>
          <option value="VA">Virginia</option>
          <option value="WA">Washington</option>
          <option value="WV">West Virginia</option>
          <option value="WI">Wisconsin</option>
          <option value="WY">Wyoming</option>
          <option value="PR">Puerto Rico</option>
          <option value="VI">Virgin Island</option>
          <option value="MP">Northern Mariana Islands</option>
          <option value="GU">Guam</option>
          <option value="AS">American Samoa</option>
          <option value="PW">Palau</option>
        </select>
      </font></td>
      <td width="46"><div align="right"><font face="Arial, Helvetica, Verdana, sans-serif" size="2"> Zip          
      </font></div></td>
    
      <td width="237"><font face="Arial, Helvetica, Verdana, sans-serif" size="2">
        <input name="zip" type="text" id="zip" size="9" maxlength="9">
      </font></td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Password 1</div></td>
      <td><input name="pwd2" type="password" id="pwd22" size="25" maxlength="15"></td>
      <td class="style4"><div align="right">Password 2 </div></td>
      <td class="style4"><input name="pwd1" type="password" id="pwd1" size="25" maxlength="15"></td>
      <td colspan="2">&nbsp;</td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Hospital</div></td>
      <td colspan="6"><select name="hospital" id="select">
        <option value="UF" selected>Shands at UF</option>
        <option value="Shands">Shands at AGH</option>
        <option value="VA">Verterans Administration-Gainesville</option>
            </select></td>
    </tr>
    <tr> 
      <td height="26" class="style4"><div align="right">Position</div></td>
      <td><select name="position" id="select2">
        <option value="1">User</option>
        <option value="2" selected>Surgeon</option>
        <option value="3">Adminstrator</option>
            </select>        </td>
      <td><div align="right"><span class="style4">Type of Surgeon</span>      </div></td>
      <td><select name="surgeon_type" id="select3">
        <option value="NA" selected>NA</option>
        <option value="Heart">Heart</option>
        <option value="Eye">Eye</option>
        <option value="Brain">Brain</option>
        <option value="Knee">Knee</option>
      </select></td>
      <td colspan="2">&nbsp;
     
      </td>
      
    </tr>
    <tr>
      <td height="26"><div align="right" class="style4">Email</div></td>
      <td colspan="6"><input name="email" type="text" id="city3" size="25" maxlength="25"></td>
    </tr>
    <tr> 
      <td height="26">&nbsp;</td>
      <td colspan="6"><input name="add" type="submit" id="add2" value="Add User"> <input type="reset" name="Reset" value="Reset"></td>
    </tr>
  </table>
  </form>
  
  </td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
