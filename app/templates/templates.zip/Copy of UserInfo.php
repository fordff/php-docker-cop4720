<?
include("../db_class_info.php");      //include oracle class file
import_request_variables("gP","var_");  // get all  post variables and append with var
?>
<html>
<head>
<title>User Info</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="pragma" content="no-cache">
<link href="../../StyleSheets/mypage.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="1247" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr> 
    <td height="60" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr> 
          <td width="1248" height="56"><img src=".././images/banner2.jpg" width="1248" height="60"></td>
          <td width="4"></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="13" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1247" height="13">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="196" height="776" valign="top"><table width="196" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="196" height="776" bgcolor="#006699">
		<div id="navlist"> 
              <ul>
                <li class="tbletitle"> 
                  <div align="center">Admin Functions</div>
                </li>
                <li><a href="UserAdd.php">Add User</a></li>
                <li><a href="/COP4720/Admin/Delete_User.php">Delete User</a></li>
                <li><a href="UserInfo.php">View User</a></li>
                <li><a href="/COP4720/Admin/Modify_User.php">Modify User</a></li>
                <li class="tbletitle"> 
                  <div align="center">Patient Functions</div>
                </li>
                <li><a href="/COP4720/Patient/View_Patient.php">View Patient</a></li>
                <li><a href="/COP4720/Patient/Add_Patient.php">Add Patient</a></li>
                <li><a href="/COP4720/Patient/Delete_Patient.php">Delete Patient</a></li>
                <li><a href="/COP4720/Patient/Modify_Patient.php">Modify Patient</a></li>
                <li><a href="/COP4720/Patient/Outcome_entry.php">Patient Outcome</a></li>
                <li><a href="/COP4720/Patient/Complications_entry.php"> Complication
                  Info</a></li>
                <li><a href="/COP4720/Patient/Diagonis_Entry.php">Patient Diagnosis</a></li>
                <li><a href="/COP4720/Patient/Image_entry.php"> Patient Image</a></li>
                <li class="tbletitle"> 
                  <div align="center">Hospital Functions</div>
                </li>
                <li><a href="/COP4720/Admin/Add_Hospital.php"> New Hospital</a></li>
                <li><a href="/COP4720/Admin/Modify_Hospital.php">Modify Hospital</a></li>
                <li><a href="/COP4720_Website/Admin/Reports.php">Generate Reports</a></li>
                <li><a href="/COP4720_Website/Admin/Edit_Lists.php">Maintain Lists</a></li>
                <li><a href="/COP4720/logout.php">Logout</a></li>
              </ul>
            </div>
		�</td>
      </tr>
    </table></td>
    <td width="13" valign="top"><table width="13" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="13" height="776">&nbsp;</td>
      </tr>
    </table></td>
    <td width="1038" valign="top"><table width="1038" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1038" height="170" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="1042" height="170" bgcolor="#FFFFFF">
			<form method="post" enctype="multipart/form-data" name="query" target="_self" id="query">
              <table width="745" border="0" align="center" cellpadding="3" class="border">
    <tr class="tbletitle"> 
      <td colspan="3" align="center">User Search </td>
    </tr>
    <tr> 
      <td width="198"  align="right" class="style4">Search For </td>
      <td width="175" > 
	  <input name="query" type="text" size="35" maxlength="25"></td>
      <td width="344" valign="middle"> <span class="style4">&nbsp;</span></td>
    </tr>
    <tr>
      <td align="right" class="style4">Search By</td>
      <td ><select name="search_by" id="select2">
        <option value="Last_Name">Lastname</option>
        <option value="First_Name">Firstname</option>
        <option value="Userid" selected>Userid</option>
            </select></td>
      <td valign="middle" >&nbsp;</td>
    </tr>
    <tr> 
      <td align="right" class="style4">Type of Search&nbsp; </td>
      <td ><select name="query_type" id="select3">
        <option value="exact">Exact Match</option>
        <option value="like" selected>Soundex</option>
            </select> </td>
      <td valign="middle" >&nbsp; </td>
    </tr>
    <tr> 
      <td align="right"><span class="style4">&nbsp;Type of User</span>
        </td>
      <td align="left"> 
        <select name="user_type" id="select">
          <option value="all" selected>All</option>
          <option value="admin">Admin</option>
          <option value="surgeon">Surgeon</option>
          <option value="user">User</option>
        </select>        </td>
      <td align="center"><input type="submit" name="Query" value="Search"></td>
    </tr>
  </table>
			</form>
  			</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="606" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="1038" height="606" bgcolor="#FFFFFF" valign="top">
			<?	if(isset($var_Query))
	{
	 $results = array();	
	 $db = new Oracle;  
   	 $db->logOn();
	 $select= "*";
	 $from = $db->User_table;
	 if ($var_query_type == "exact")
	 {
	   switch($var_user_type)
			{
			 case "all" :
			 $where = $var_search_by." = '$var_query'";
			 break;
			 case "admin" :
			 $where = $var_search_by." = '$var_query' and Position = '1'";
			  break;
			 case "surgeon":
			 $where = $var_search_by." = '$var_query' and Position = '2'";
			 break;
			 case "user":
			 $where = $var_search_by." = '$var_query' and Position =  '3'";
			 break;
			}
	 $db->queryDB($select,$from,$where);
	 if ($db->fetch()) //check password
	      {  
	        $found = "true";
            $results=$db->result_array; 
			$userid	   = $results['Userid'];
	        $lastname  = $results['LAST_NAME'];   
			$firstname = $results['FIRST_NAME'];   
	        $address1  = $results['ADDRESS1'];   
	        $city      = $results['CITY'];
			$state     = $results['STATE'];   
			$zip       = $results['ZIP'];   
	        $pwd1      = $results['PASSWD1'];   
	        $pwd2      = $results['PASSWD2'];   
			$regdate   = $results['REG_DATE'];
			$hospid	   = $results['HOSPID'];
			$position  = $results['POSITION'];
	      }  
	     else $error = "Record Not Found";     
        $db->logOff();  
      	 }//end exact
     elseif ($var_query_type=="like") 
     {
     	switch($var_user_type)
			{
			 case "all" :
			 $where = $var_search_by." LIKE '%$var_query'%";
			 break;
			 case "admin" :
			 $where = $var_search_by." LIKE '%$var_query%' and Position = '1'";
			  break;
			 case "surgeon":
			 $where = $var_search_by." LIKE '%$var_query%' and Position = '2'";
			 break;
			 case "user":
			 $where = $var_search_by." LIKE '%$var_query%' and Position =  '3'";
			 break;
			}
	 $db->queryDB($select,$from,$where);
	 echo('<table width="467" border="1" align="center" >');
	 while ($db->fetch()) //check password
	      {  
	        $found = "true";
            $results=$db->result_array; 
			$userid	   = $results['Userid'];
	        $lastname  = $results['Last_Name'];   
			$firstname = $results['First_Name'];   
	        $address1  = $results['ADDRESS1'];   
	        $city      = $results['CITY'];
			$state     = $results['STATE'];   
			$zip       = $results['ZIP'];   
	        $pwd1      = $results['PASSWD1'];   
	        $pwd2      = $results['PASSWD2'];   
			$regdate   = $results['REG_DATE'];
			$hospid	   = $results['hopsid'];
			$position  = $results['position'];
				        
	      }  
	     echo('</table> <br>'); 
        $db->logOff();  
     }//end like query
  }		 
?>
			
			
			&nbsp;
			<form action="many.php" method="post"  name="form2" id="form2">
			<table width="100%" border="1">
              <tr class="style4">
                <th width="13%" scope="col"><a href="UserInfo.php" target="_self">Record</a></th>
                <th width="13%"  scope="col">Userid</th>
                <th width="13%"  scope="col">Last Name </th>
                <th width="13%"  scope="col">Firstname</th>
                <th width="13%" scope="col">Hospid</th>
                <th width="13%" scope="col">Position</th>
                <th width="7%" scope="col"> <input name="Info" type="submit" id="Info" value="Info"></th>
                <th width="7%" scope="col"><input name="Modify" type="submit" id="Modify" value="Modify"></th>
                <th width="7%" scope="col"><input name="Delete" type="submit" id="Delete" value="Delete"></th>
              </tr>
              <tr bgcolor="#0568A3" class="style4">
                <td bgcolor="#FFFFFF">1</td>
                <td>12345678912345679</td>
                <td>Frank</td>
                <td>Ford</td>
                <td>Shands at UF</td>
                <td>Surgeon</td>
                <td align="center"><input type="checkbox" name="checkbox" value="checkbox"></td>
                <td align="center">
                  <input type="checkbox" name="checkbox2" value="checkbox">               </td>
                <td align="center"><input type="checkbox" name="checkbox3" value="checkbox"></td>
              </tr>
            </table>	
			</form>		
			<br><form action="" method="post" enctype="multipart/form-data" name="form1" target="_self">
			  <table width="520" border="0" align="center" class="borderCopy">
    <tr> 
      <td colspan="4" class="tbletitle">User Info</td>
    </tr>
    <tr> 
      <td width="112" class="style4"><div align="right">Last Name</div></td>
      <td colspan="3" class="style4"><?php echo($lastname); ?>&nbsp;</td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">First Name</div></td>
      <td colspan="3" class="style4"><?php echo($firstname); ?>&nbsp;</td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Address</div></td>
      <td colspan="3" class="style4"><?php echo($address1); ?>&nbsp;</td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">City</div></td>
      <td colspan="3" class="style4"><?php echo($city); ?>&nbsp;</td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">State</div></td>
      <td colspan="3" class="style4"><?php echo($state); ?>&nbsp;</td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Zip</div></td>
      <td colspan="3" class="style4"><?php echo ($zip); ?>&nbsp;</td>
    </tr>
    <tr> 
      <td height="26" class="style4"><div align="right">Position</div></td>
      <td colspan="3" class="style4"><?php echo($position) ?>&nbsp;</td>
    </tr>
    <tr> 
      <td height="26" class="style4"><div align="right">Hospital</div></td>
      <td colspan="3" class="style4"><?php echo($hospid) ?>&nbsp;</td>
    </tr>
    <tr>
      <td height="26" class="style4"><div align="right">Email</div></td>
      <td colspan="3" class="style4"><?        ?>&nbsp;fordff@ufl.edu</td>
    </tr>
    <tr>
      <td height="26" class="style4"><div align="center"></div></td>
      <td class="style4"><div align="center">
        <input name="delete" type="submit" id="Delete" value="Delete">
      </div></td>
      <td class="style4"><div align="center">
        <input name="Modify" type="submit" id="Modify" value="Modify">
      </div></td>
       </tr>
  </table>
			
			  </form></td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
