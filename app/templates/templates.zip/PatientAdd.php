<?
include("db_class_info.php");      //include oracle class file
import_request_variables("gP","var_");  // get all  post variables and append with var
?>
<html>
<head>
<title>Add Patient</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../StyleSheets/mypage.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="1247" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr> 
    <td height="60" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr> 
          <td width="1248" height="56"><img src="./images/banner2.jpg" width="1248" height="60"></td>
          <td width="4"></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="13" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1247" height="13">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="196" height="776" valign="top"><table width="196" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="196" height="776" bgcolor="#006699">
        <div id="navlist"> 
              <ul>
                <li class="tbletitle"> 
                  <div align="center">Admin Functions</div>
                </li>
                <li><a href="Admin/UserAdd.php">Add User</a></li>
                <li><a href="/COP4720/Admin/Delete_User.php">Delete User</a></li>
                <li><a href="Admin/UserInfo.php">View User</a></li>
                <li><a href="/COP4720/Admin/Modify_User.php">Modify User</a></li>
                <li class="tbletitle"> 
                  <div align="center">Patient Functions</div>
                </li>
                <li><a href="/COP4720/Patient/View_Patient.php">View Patient</a></li>
                <li><a href="/COP4720/Patient/Add_Patient.php">Add Patient</a></li>
                <li><a href="/COP4720/Patient/Delete_Patient.php">Delete Patient</a></li>
                <li><a href="/COP4720/Patient/Modify_Patient.php">Modify Patient</a></li>
                <li><a href="/COP4720/Patient/Outcome_entry.php">Patient Outcome</a></li>
                <li><a href="/COP4720/Patient/Complications_entry.php"> Complication
                  Info</a></li>
                <li><a href="/COP4720/Patient/Diagonis_Entry.php">Patient Diagnosis</a></li>
                <li><a href="/COP4720/Patient/Image_entry.php"> Patient Image</a></li>
                <li class="tbletitle"> 
                  <div align="center">Hospital Functions</div>
                </li>
                <li><a href="/COP4720/Admin/Add_Hospital.php"> New Hospital</a></li>
                <li><a href="/COP4720/Admin/Modify_Hospital.php">Modify Hospital</a></li>
                <li><a href="/COP4720_Website/Admin/Reports.php">Generate Reports</a></li>
                <li><a href="/COP4720_Website/Admin/Edit_Lists.php">Maintain Lists</a></li>
                <li><a href="/COP4720/logout.php">Logout</a></li>
              </ul>
            </div>
            &nbsp;</td>
      </tr>
    </table></td>
    <td width="13" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="13" height="776">&nbsp;</td>
      </tr>
    </table></td>
    <td width="1038" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1038" height="170" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="1042" height="170" bgcolor="#999999"><!--DWLayoutEmptyCell-->&nbsp;			</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td height="606" valign="top"><table width="1038" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="1038" height="606" bgcolor="#FFFFFF" valign="top"><br>
<form action="" method="post" enctype="multipart/form-data" name="new_entry" target="_self" id="new_entry">
  <table width="686" border="1" align="center" class="border">
    <tr> 
      <td colspan="5" class="tbletitle">Patient Infomation</td>
    </tr>
    <tr> 
      <td width="108" class="style4"><div align="right">Medical Record </div></td>
      <td colspan="4"> <input name="medrecnum" type="text" id="medrecnum" size="25" maxlength="25"></td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Last Name</div></td>
      <td width="197"><input name="lastname" type="text" id="lastname" size="25" maxlength="25"></td>
      <td width="84" class="style4"><div align="right">First Name</div></td>
      <td width="254"><input name="firstname" type="text" id="firstname" size="25" maxlength="25"></td>
      <td width="9">&nbsp;</td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Address</div></td>
      <td colspan="4"><input name="address" type="text" id="address2" size="25" maxlength="25"></td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">City</div></td>
      <td><input name="city" type="text" id="city" size="25" maxlength="25"></td>
      <td class="style4"><div align="right">State</div></td>
      <td><select name="State">
         <option value="AL">Alabama</option>
        <option value="AK">Alaska</option>
        <option value="AZ">Arizona</option>
        <option value="AR">Arkansas</option>
        <option value="CA">California</option>
        <option value="CO">Colorado</option>
        <option value="CT">Connecticut</option>
        <option value="DE">Delaware</option>
        <option value="DC">District of Columbia</option>
        <option value="FL">Florida</option>
        <option value="GA">Georgia</option>
        <option value="HI">Hawaii</option>
        <option value="ID">Idaho</option>
        <option value="IL">Illinois</option>
        <option value="IN">Indiana</option>
        <option value="IA">Iowa</option>
        <option value="KS">Kansas</option>
        <option value="KY">Kentucky</option>
        <option value="LA">Louisiana</option>
        <option value="ME">Maine</option>
        <option value="MD">Maryland</option>
        <option value="MA">Massachusetts</option>
        <option value="MI">Michigan</option>
        <option value="MN">Minnesota</option>
        <option value="MS">Mississippi</option>
        <option value="MO">Missouri</option>
        <option value="MT">Montana</option>
        <option value="NE">Nebraska</option>
        <option value="NV">Nevada</option>
        <option value="NH">New Hampshire</option>
        <option value="NJ">New Jersey</option>
        <option value="NM">New Mexico</option>
        <option value="NY">New York</option>
        <option value="NC">North Carolina</option>
        <option value="ND">North Dakota</option>
        <option value="OH">Ohio</option>
        <option value="OK">Oklahoma</option>
        <option value="OR">Oregon</option>
        <option value="PA">Pennsylvania</option>
        <option value="RI">Rhode Island</option>
        <option value="SC">South Carolina</option>
        <option value="SD">South Dakota</option>
        <option value="TN">Tennessee</option>
        <option value="TX">Texas</option>
        <option value="UT">Utah</option>
        <option value="VT">Vermont</option>
        <option value="VA">Virginia</option>
        <option value="WA">Washington</option>
        <option value="WV">West Virginia</option>
        <option value="WI">Wisconsin</option>
        <option value="WY">Wyoming</option>
        <option value="PR">Puerto Rico</option>
        <option value="VI">Virgin Island</option>
        <option value="MP">Northern Mariana Islands</option>
        <option value="GU">Guam</option>
        <option value="AS">American Samoa</option>
        <option value="PW">Palau</option>
      </select></td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Zip</div></td>
      <td colspan="4"><input name="zip" type="text" id="zip" size="8" maxlength="8"></td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Date Of Birth</div></td>
      <td colspan="4"><input name="DOB" type="text" id="DOB2" size="15" maxlength="15">
        <span class="style4">Format: MM-DD-YY </span></td>
    </tr>
    <tr> 
      <td class="style4"><div align="right">Treating Hospital</div></td>
      <td colspan="4"><select name="hospital">
        <option value="UF" selected>Shands at UF</option>
        <option value="Shands">Shands at AGH</option>
        <option value="VA">Verterans Administration-Gainesville</option>
      </select></td>
    </tr>
    <tr> 
      <td class="style4"><div align="right"></div></td>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr> 
      <td height="26" class="style4">&nbsp;</td>
      <td colspan="4">&nbsp;</td>
    </tr>
    <tr> 
      <td height="26">&nbsp;</td>
      <td colspan="4"><input name="Add" type="submit" id="Add2" value="Add Patient">
        <input type="reset" name="Reset" value="Reset"></td>
    </tr>
  </table>
  </form>
  <?

				 echo("id ".$var_medrecnum);
				 echo("<br>");
				 echo("ln ".$var_lastname);
				  echo("<br>");
				 echo("fn ".$var_firstname);
				  echo("<br>");
				 echo("add ".$var_address);
				  echo("<br>");
				  echo("city ".$var_city);
				   echo("<br>");
				echo("state ".$var_State);
				 echo("<br>");
				 echo("zip ".$var_zip);
				  echo("<br>");
				 echo("dob ".$var_DOB);
				  echo("<br>");
				echo("hosp".$var_hospital);
				 echo("<br>");
				echo($regdate);
				 echo("Hospital ".$var_hospital);
				 echo("<br>");
				echo("Positon ".$var_position);
  
  
  ?>
  </td>
          </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
