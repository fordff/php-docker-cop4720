<?
include("db_class_info.php");      //include oracle class file
import_request_variables("gP","var_");  // get all  post variables and append with var
?>
<html>
<head>
<title>Patient Info</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../StyleSheets/mypage.css" rel="stylesheet" type="text/css">
</head>

<body>

<table width="1247" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr> 
    <td height="60" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr> 
          <td width="1248" height="56"><img src="./images/banner2.jpg" width="1248" height="60"></td>
          <td width="4"></td>
        </tr>
    </table></td>
  </tr>
  <tr>
    <td height="13" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="1247" height="13">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td width="196" height="776" valign="top"><table width="196" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="196" height="776" bgcolor="#006699">
        <div id="navlist"> 
              <ul>
                <li class="tbletitle"> 
                  <div align="center">Admin Functions</div>
                </li>
                <li><a href="Admin/UserAdd.php">Add User</a></li>
                <li><a href="/COP4720/Admin/Delete_User.php">Delete User</a></li>
                <li><a href="Admin/UserInfo.php">View User</a></li>
                <li><a href="/COP4720/Admin/Modify_User.php">Modify User</a></li>
                <li class="tbletitle"> 
                  <div align="center">Patient Functions</div>
                </li>
                <li><a href="/COP4720/Patient/View_Patient.php">View Patient</a></li>
                <li><a href="/COP4720/Patient/Add_Patient.php">Add Patient</a></li>
                <li><a href="/COP4720/Patient/Delete_Patient.php">Delete Patient</a></li>
                <li><a href="/COP4720/Patient/Modify_Patient.php">Modify Patient</a></li>
                <li><a href="/COP4720/Patient/Outcome_entry.php">Patient Outcome</a></li>
                <li><a href="/COP4720/Patient/Complications_entry.php"> Complication
                  Info</a></li>
                <li><a href="/COP4720/Patient/Diagonis_Entry.php">Patient Diagnosis</a></li>
                <li><a href="/COP4720/Patient/Image_entry.php"> Patient Image</a></li>
                <li class="tbletitle"> 
                  <div align="center">Hospital Functions</div>
                </li>
                <li><a href="/COP4720/Admin/Add_Hospital.php"> New Hospital</a></li>
                <li><a href="/COP4720/Admin/Modify_Hospital.php">Modify Hospital</a></li>
                <li><a href="/COP4720_Website/Admin/Reports.php">Generate Reports</a></li>
                <li><a href="/COP4720_Website/Admin/Edit_Lists.php">Maintain Lists</a></li>
                <li><a href="/COP4720/logout.php">Logout</a></li>
              </ul>
            </div>
            &nbsp;</td>
      </tr>
    </table></td>
    <td width="13" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td width="13" height="776">&nbsp;</td>
      </tr>
    </table></td>
    <td width="1038" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td height="170" colspan="3" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="1042" height="170" bgcolor="#B8C9DD">&nbsp;	<form action="" method="post" enctype="multipart/form-data" target="_self">
  <table width="654" border="0" align="center" cellpadding="3" class="border">
    <tr class="tbletitle"> 
      <td colspan="4" align="center" class="MyCSS">Patient Search </td>
    </tr>
    <tr> 
      <td width="134" align="right" class="style4">Search For </td>
      <td width="180">
         <input name="query" type="text" size="30" maxlength="25">
      </td>
      <td width="105"><div align="right" class="style4">Search By </div></td>
      <td width="130"><select name="search_by" id="search_by">
        <option value="Lastname" selected>Lastname</option>
        <option value="Firstname">Firstname</option>
        <option value="Med_Record_Num">Medical Record</option>
        <option value="Address1">Address</option>
        <option value="Birthdate">Birthdate</option>
                        </select></td>
    </tr>
    <tr> 
      <td align="right" class="style4">Type of Search </td>
      <td colspan="3" ><select name="query_type" id="select">
        <option value="exact" selected>Exact Search</option>
        <option value="like">Soundex Search</option>
                  </select>
      </td>
    </tr>
    <tr> 
	  <td align="right">&nbsp;
	  </td>
      <td  colspan="4"align="left">  &nbsp; <input type="submit" name="Query" value="Search"></td>
   </tr>
  </table>
</form>		</td>
          </tr>
        </table></td>
      </tr>
      <tr>
        <td width="510" height="606" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="510" height="606" valign="top"><table width="96%"  border="1" class="style4">
                <tr class="tbletitle">
                  <td colspan="2">Diagnosis</td>
                  </tr>
                <tr>
                  <td><select name="select">
                  </select></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td><input type="submit" name="Submit" value="Forward">
                    <input type="submit" name="Submit2" value="Submit">
                    <input type="submit" name="Submit3" value="Back"></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  </tr>
              </table>
              <br>
              <table width="96%"  border="1" class="style4">
                <tr class="tbletitle">
                  <td colspan="2">Procedure</td>
                  </tr>
                <tr>
                  <td><select name="select2">
                  </select></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td><input type="submit" name="Submit4" value="Forward">
                    <input type="submit" name="Submit22" value="Submit">
                    <input type="submit" name="Submit32" value="Back"></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  </tr>
              </table>
              <br>
              <table width="96%"  border="1" class="style4">
                <tr class="tbletitle">
                  <td colspan="2">Outcome</td>
                  </tr>
                <tr>
                  <td><select name="select3">
                  </select></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td><input type="submit" name="Submit5" value="Forward">
                    <input type="submit" name="Submit23" value="Submit">
                    <input type="submit" name="Submit33" value="Back"></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  </tr>
              </table>
              <br><table width="96%"  border="1" class="style4">
                <tr class="tbletitle">
                  <td colspan="2">Complications</td>
                  </tr>
                <tr>
                  <td><select name="select3">
                  </select></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td><input type="submit" name="Submit5" value="Forward">
                    <input type="submit" name="Submit23" value="Submit">
                    <input type="submit" name="Submit33" value="Back"></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  </tr>
              </table>
              <table width="96%"  border="1" class="style4">
                <tr class="tbletitle">
                  <td colspan="2">Image Entry </td>
                  </tr>
                <tr>
                  <td><input type="file" name="file"></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td><input type="submit" name="Submit232" value="Submit"></td>
                  <td>&nbsp;</td>
                  </tr>
                <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  </tr>
              </table>&nbsp;</td>
          </tr>
        </table></td>
        <td width="527" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="527" height="606" valign="top"><table width="100%"  border="1">
              <tr>
                <th width="19%" class="style4" scope="row">Userid</th>
                <td width="63%">&nbsp;</td>
                <td width="9%">&nbsp;</td>
                <td width="9%">&nbsp;</td>
              </tr>
              <tr>
                <th class="style4" scope="row">LastName </th>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <th class="style4" scope="row">First name </th>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <th class="style4" scope="row">Address</th>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <th class="style4" scope="row">Procedure</th>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <th class="style4" scope="row">Complication</th>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <th class="style4" scope="row">Diagnoisis</th>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <th class="style4" scope="row">Outcome</th>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <th class="style4" scope="row">Images</th>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <th class="style4" scope="row">&nbsp;</th>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </table>
			</td>
          </tr>
        </table></td>
        <td width="1">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
